<template>
  <div class="liveStreaming">
      <h1 style="fontSize:22px;fontWeight:bold;textAlign:center;marginTop:20px">look直播</h1>
  </div>
</template>

<script>
export default {
    name:"LiveStreaming",
}
</script>

<style scoped>

</style>