<template>
  <div class="myseilffm">
      <h1 style="fontSize:22px;fontWeight:bold;textAlign:center;marginTop:20px">私人FM</h1>
  </div>
</template>

<script>
export default {
    name:"MyseilfFM",
}
</script>

<style scoped>

</style>