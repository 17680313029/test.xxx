export const NOW_MUSIC = 'nowMusic';
export const NOW_MUSICMENU = 'nowMusicMenu';
export const USER_SONGLIST = 'userSonglist';
export const MUSIC_LISTIDS = 'musiclistIds';
export const ADD_COUNT = 'addcount';
export const SUB_COUNT = 'subcount';
export const CLEAR_COUNT = 'clearcount';
export const SET_COUNT = 'setcount';
export const SET_DURATION = 'setduration';
export const SET_PLAY = 'setplay';

